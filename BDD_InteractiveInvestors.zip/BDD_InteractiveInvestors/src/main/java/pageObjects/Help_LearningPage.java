package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Help_LearningPage {

	public Help_LearningPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.XPATH, using = "//span[@title='Help & Learning']")
	private WebElement DropdownMenu_HelpAndLearning;

	@FindBy(how = How.XPATH, using = "//div[@id='navigationItemHelpLearning']//a[@class='chakra-link chakra-link css-244brj'][normalize-space()='Ethical Investing']")
	private WebElement Link_EthicalInvesting;

	@FindBy(how = How.XPATH, using = "//h1[text()='Ethical investing']")
	private WebElement txtField_EthicalInvestingText;



	public void clickOn_Help_LearningMenu() {
		DropdownMenu_HelpAndLearning.click();

	}

	public void clickOn_LinkEthicalInvesting() {
		Link_EthicalInvesting.click();

	}

	public void ObtainText_ethicalInvestingText() {
		txtField_EthicalInvestingText.getText();
		
		System.out.println(txtField_EthicalInvestingText.getText());

	}


	public boolean isEthicalInvestingTextPresent(String EthicalText) {
	
		 try{
	            boolean ethicalInvestingText = txtField_EthicalInvestingText.getText().contains(EthicalText);
	            return ethicalInvestingText;
	        } catch (Exception e){
	            return false;
	        }
	}
}
