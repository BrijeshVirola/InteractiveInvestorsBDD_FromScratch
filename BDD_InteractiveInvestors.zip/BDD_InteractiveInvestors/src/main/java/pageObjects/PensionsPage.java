package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PensionsPage {
	
	
	public PensionsPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.XPATH, using = "//span[@title='Pensions']")
	private WebElement DropdownMenu_Pensions;

	@FindBy(how = How.XPATH, using = "//a[contains(text(),'SIPP Charges')]")
	private WebElement Link_SIPPCharges;

	@FindBy(how = How.XPATH, using = "//h1[text()='SIPP fees and charges']")
	private WebElement txtField_SIPPChargesText;

	@FindBy(how = How.XPATH, using = "//h2[normalize-space()='SIPP fees at a glance']")
	private WebElement txtField_SIPPFeedsAtGlanceText;

	public void clickOn_PensionsMenu() {
		DropdownMenu_Pensions.click();

	}

	public void clickOn_LinkSIPPCharges() {
		Link_SIPPCharges.click();

	}

	public void ObtainText_sippFeesAndChargesText() {
		txtField_SIPPChargesText.getText();
		
		System.out.println(txtField_SIPPChargesText.getText());

	}

	public void ObtainText_FeedsAtGlancneText() {
		txtField_SIPPFeedsAtGlanceText.getText();
		
		System.out.println(txtField_SIPPFeedsAtGlanceText.getText());
	
	}

	public boolean isSippPageTextPresent(String SippFees) {
	
		 try{
	            boolean sippfeesText = txtField_SIPPChargesText.getText().contains(SippFees);
	            return sippfeesText;
	        } catch (Exception e){
	            return false;
	        }
	}

}
