package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class InvestmentsPage {

	public InvestmentsPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.XPATH, using = "//span[@title='Investments']")
	private WebElement DropdownMenu_Investments;

	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Top UK Shares')]")
	private WebElement Link_TopUKShares;

	@FindBy(how = How.XPATH, using = "//h1[@class='text-jumbo']")
	private WebElement txtField_TopPerformingUKShares;



	public void clickOn_InvestmentsMenu() {
		DropdownMenu_Investments.click();

	}

	public void clickOn_LinkTopUKShares() {
		Link_TopUKShares.click();

	}

	public void ObtainText_TopPerformingSharesText() {
		txtField_TopPerformingUKShares.getText();
		
		System.out.println(txtField_TopPerformingUKShares.getText());

	}


	public boolean isTopSharesTextPresent(String TopUKShares) {
	
		 try{
	            boolean topSharesText = txtField_TopPerformingUKShares.getText().contains(TopUKShares);
	            return topSharesText;
	        } catch (Exception e){
	            return false;
	        }
	}
}
