package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ServicesPage {

	public ServicesPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.XPATH, using = "//span[@title='Services']")
	private WebElement DropdownMenu_Services;

	@FindBy(how = How.XPATH, using = "//a[@class='chakra-link chakra-link css-244brj'][normalize-space()='Trading Account']")
	private WebElement Link_TradingAccount;

	@FindBy(how = How.XPATH, using = "//h1[@class='text-jumbo']")
	private WebElement txtField_TradingAccountText;

	@FindBy(how = How.XPATH, using = "//h2[normalize-space()='Benefits of our trading account']")
	private WebElement txtField_BenefitsTradingAccountText;

	public void clickOn_ServicesMenu() {
		DropdownMenu_Services.click();

	}

	public void clickOn_LinkTradingAccount() {
		Link_TradingAccount.click();

	}

	public void ObtainText_TradingAccountText() {
		txtField_TradingAccountText.getText();
		
		System.out.println(txtField_TradingAccountText.getText());
	
	}

	public void ObtainText_TradingAccountBenefits() {
		txtField_BenefitsTradingAccountText.getText();
		
		System.out.println(txtField_BenefitsTradingAccountText.getText());
		
	}

	public boolean isTextPresent(String tradingText) {
	
		 try{
	            boolean trAccountText = txtField_TradingAccountText.getText().contains(tradingText);
	            return trAccountText;
	        } catch (Exception e){
	            return false;
	        }
	}
	
	

}
