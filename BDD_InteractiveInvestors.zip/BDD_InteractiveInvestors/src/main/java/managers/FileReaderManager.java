package managers;

import dataProviders.ConfigFileReader;

import java.io.FileNotFoundException;

public class FileReaderManager {

    //class and
    private static FileReaderManager fileReaderManager = new FileReaderManager();
    private static ConfigFileReader configFileReader;

    private FileReaderManager(){

    }

    public static FileReaderManager getInstance(){
        return fileReaderManager;
    }

    public ConfigFileReader getConfigReader() throws FileNotFoundException {
        return (configFileReader == null) ? new ConfigFileReader() : configFileReader;
    }
}
