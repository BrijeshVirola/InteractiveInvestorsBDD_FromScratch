package managers;

import org.openqa.selenium.WebDriver;

import pageObjects.Help_LearningPage;
import pageObjects.HomePage;
import pageObjects.InvestmentsPage;
import pageObjects.PensionsPage;
import pageObjects.ServicesPage;

import java.io.FileNotFoundException;

public class PageObjectManager {

    //class and methods to manage all pages the user navigates for an E2E scenario tests
    private WebDriver driver;
    private HomePage homePage;
    private ServicesPage servicesPage;
    private PensionsPage pensionsPage;
    private InvestmentsPage investmentsPage;
    private Help_LearningPage helpLearningPage;

    public PageObjectManager(WebDriver driver){
        this.driver = driver;
    }

    public HomePage getHomePage() throws FileNotFoundException {
       return (homePage == null) ? homePage = new HomePage(driver) : homePage;
    }

    public ServicesPage getServicesPage() throws FileNotFoundException {
        return (servicesPage == null) ? servicesPage = new ServicesPage(driver) : servicesPage;
     }
	
    public PensionsPage getPensionsPage() throws FileNotFoundException {
        return (pensionsPage == null) ? pensionsPage = new PensionsPage(driver) : pensionsPage;
     }
    
    public InvestmentsPage getInvestmentsPage() throws FileNotFoundException {
        return (investmentsPage == null) ? investmentsPage = new InvestmentsPage(driver) : investmentsPage;
     }
    
    public Help_LearningPage getHelp_LearningPage() throws FileNotFoundException {
        return (helpLearningPage == null) ? helpLearningPage = new Help_LearningPage(driver) : helpLearningPage;
     }
}
