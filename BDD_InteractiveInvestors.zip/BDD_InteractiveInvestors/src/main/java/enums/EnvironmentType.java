package enums;

//Enum specifying local and remote environment
public enum EnvironmentType {
    LOCAL,
    REMOTE
}
