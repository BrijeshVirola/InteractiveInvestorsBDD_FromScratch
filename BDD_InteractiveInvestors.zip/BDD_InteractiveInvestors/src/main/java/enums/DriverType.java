package enums;

//enum specifying Web Drivers
public enum DriverType {
    FIREFOX,
    CHROME,
    INTERNETEXPLORER
}
