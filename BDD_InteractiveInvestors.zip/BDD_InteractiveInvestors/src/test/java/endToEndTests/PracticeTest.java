package endToEndTests;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class PracticeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//WebDriverManager.chromedriver().setup();
		//System.setProperty("webdriver.chrome.driver", "/Users/bvirola/Downloads/chromedriver");
		System.setProperty("webdriver.chrome.driver", "/Users/bvirola/eclipse-workspace/BDD_InteractiveInvestors/src/test/resources/webDrivers/chromedriver");
		//System.setProperty("webdriver.gecko.driver", "/Users/bvirola/eclipse-workspace/BDD_InteractiveInvestors/src/test/resources/webDrivers/geckodriver");
		WebDriver driver = new ChromeDriver();
	   // WebDriver driver = new FirefoxDriver();
		driver.get("https://www.ii.co.uk/.");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//button[text()='Accept']")).click();
		
		driver.findElement(By.xpath("//span[@title='Services']")).click();
		driver.findElement(By.xpath("//a[@class='chakra-link chakra-link css-244brj'][normalize-space()='Trading Account']")).click();
		
		WebElement HeaderText = driver.findElement(By.xpath("//h1[@class='text-jumbo']"));
		System.out.println(HeaderText.getText());
		
		if(HeaderText.getText().contains("Trading Account")) {
			System.out.println("User on Trading Account page");
		} else {
			System.out.println("User is not on Trading Account page");
		}
		
		String ActualText = HeaderText.getText();
		String ExpectedText = "Trading Account";
		Assert.assertEquals(ExpectedText, ActualText);
		
		driver.findElement(By.xpath("//span[@title='Pensions']")).click();
		driver.findElement(By.xpath("//a[contains(text(),'SIPP Charges')]")).click();
	
		WebElement SippChargesText = driver.findElement(By.xpath("//h1[@class='text-jumbo']"));
		System.out.println(SippChargesText.getText());
		
		if(SippChargesText.getText().contains("SIPP fees and charges")) {
			System.out.println("User is on SIPP fees and charges page");
		} else {
			System.out.println("User is not on SIPP fees and charges page");
		}
		

		driver.findElement(By.xpath("//span[@title='Investments']")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Top UK Shares')]")).click();
		
		WebElement TopPerformingSharesText = driver.findElement(By.xpath("//h1[@class='text-jumbo']"));
		System.out.println(TopPerformingSharesText.getText());
		
		if(TopPerformingSharesText.getText().contains("Top performing UK shares: risers and fallers")) {
			System.out.println("User is on Top performing UK shares: risers and fallers page");
		} else {
			System.out.println("User is not on Top performing UK shares: risers and fallers page");
		}
		
		
		driver.findElement(By.xpath("//span[@title='Help & Learning']")).click();
		driver.findElement(By.xpath("//div[@id='navigationItemHelpLearning']//a[@class='chakra-link chakra-link css-244brj'][normalize-space()='Ethical Investing']")).click();
		
		WebElement EthicalInvestingText = driver.findElement(By.xpath("//h1[@class='text-jumbo']"));
		System.out.println(EthicalInvestingText.getText());
		
		if(EthicalInvestingText.getText().contains("Ethical investing")) {
			System.out.println("User is on Ethical investing page");
		} else {
			System.out.println("User is not on Ethical investing page");
		}
		
		
		
		driver.close();
		
	}

}
