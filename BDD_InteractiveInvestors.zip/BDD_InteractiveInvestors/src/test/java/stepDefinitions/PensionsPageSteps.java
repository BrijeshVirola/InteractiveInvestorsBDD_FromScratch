package stepDefinitions;

import java.io.FileNotFoundException;

import org.junit.Assert;

import Cucumber.TestContext;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObjects.PensionsPage;
import pageObjects.ServicesPage;

public class PensionsPageSteps {

	TestContext testContext;
    PensionsPage pensionsPage;

    public PensionsPageSteps(TestContext context) throws FileNotFoundException {
        testContext = context;
        
        pensionsPage = testContext.getPageObjectManager().getPensionsPage();
    }
    
	@Given("^the user clicks on Pensions Menu$")
	public void the_user_clicks_on_Pensions_Menu() throws Throwable {
	
	     pensionsPage.clickOn_PensionsMenu();
	}

	@When("^the user clicks on Sipp Charges link$")
	public void the_user_clicks_on_Sipp_Charges_link() throws Throwable {

		pensionsPage.clickOn_LinkSIPPCharges();
	}

	@Then("^the user is directed to the SIPP fees and Charges page$")
	public void the_user_is_directed_to_the_SIPP_fees_and_Charges_page() throws Throwable {

		pensionsPage.ObtainText_sippFeesAndChargesText();
		pensionsPage.ObtainText_FeedsAtGlancneText();
		
		if(pensionsPage.isSippPageTextPresent("SIPP fees and charges")) {
	          System.out.println("User on SIPP fees and charges page");
	      } else {
	          System.out.println("User is not on SIPP fees and charges page");
	      }
		Assert.assertTrue(pensionsPage.isSippPageTextPresent("SIPP fees and charges"));
	}
}
