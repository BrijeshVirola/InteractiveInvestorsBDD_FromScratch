package stepDefinitions;

import java.io.FileNotFoundException;

import org.junit.Assert;

import Cucumber.TestContext;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObjects.ServicesPage;
import static org.junit.Assert.*;

public class ServicesPageSteps {
	
	TestContext testContext;
    ServicesPage servicesPage;

    public ServicesPageSteps(TestContext context) throws FileNotFoundException {
        testContext = context;
        
        servicesPage = testContext.getPageObjectManager().getServicesPage();
    }
	
	@Given("^the user clicks on Services Menu$")
	public void the_user_clicks_on_Services_Menu() throws Throwable {
       servicesPage.clickOn_ServicesMenu();
	}
	
	@When("^the user clicks on the Trading Account option$")
	public void the_user_clicks_on_the_Trading_Account_option() throws Throwable {
	
		servicesPage.clickOn_LinkTradingAccount();
	  
	}

	@Then("^the user directed to Trading Account page$")
	public void the_user_directed_to_Trading_Account_page() throws Throwable {
	   
	  servicesPage.ObtainText_TradingAccountText();
	  
	  if(servicesPage.isTextPresent("Trading Account")) {
          System.out.println("User on Trading Account page");
      } else {
          System.out.println("User is not on Trading Account page");
      }
	  
	 Assert.assertTrue(servicesPage.isTextPresent("Trading Account"));
	 
	  
	}
}
