package stepDefinitions;

import java.io.FileNotFoundException;

import Cucumber.TestContext;
import cucumber.api.java.en.Given;
import pageObjects.HomePage;

public class HomePageSteps {
	
	 TestContext testContext;
	    HomePage homePage;

	    public HomePageSteps(TestContext context) throws FileNotFoundException {
	        testContext = context;
	        homePage = testContext.getPageObjectManager().getHomePage();
	    }

	    @Given("^the user is on the home page$")
	    public void the_user_is_on_the_home_page() throws Throwable {
	        
	    	
	    	System.out.println("Automating Interactive Investors Navigation Functionality");
	        homePage.navigateTo_HomePage();
	    }

	    @Given("^the user accepts the cookie policy$")
	    public void the_user_accepts_the_cookie_policy() throws Throwable {
	      
	      System.out.println("Accepting Cookie Policy");	
	      homePage.clickOn_AcceptCookiePolicy();
	    }
}
