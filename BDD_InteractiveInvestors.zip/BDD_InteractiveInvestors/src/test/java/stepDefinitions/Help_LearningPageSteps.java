package stepDefinitions;

import java.io.FileNotFoundException;

import org.junit.Assert;

import Cucumber.TestContext;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObjects.Help_LearningPage;
import pageObjects.InvestmentsPage;

public class Help_LearningPageSteps {
	
	
	TestContext testContext;
    Help_LearningPage helpLearningPage;

    public Help_LearningPageSteps(TestContext context) throws FileNotFoundException {
        testContext = context;
        
        helpLearningPage = testContext.getPageObjectManager().getHelp_LearningPage();
    }
    
	@Given("^the user clicks on Help & Learning Menu$")
	public void the_user_clicks_on_Help_Learning_Menu() throws Throwable {

		helpLearningPage.clickOn_Help_LearningMenu();
	}

	@When("^the user clicks on Ethical Investing link$")
	public void the_user_clicks_on_Ethical_Investing_link() throws Throwable {
 
		helpLearningPage.clickOn_LinkEthicalInvesting();
		
	}

	@Then("^the user is directed to the Ethical Investing page$")
	public void the_user_is_directed_to_the_Ethical_Investing_page() throws Throwable {

		helpLearningPage.ObtainText_ethicalInvestingText();
		
		if(helpLearningPage.isEthicalInvestingTextPresent("Ethical investing")) {
	          System.out.println("User on Ethical investing page");
	      } else {
	          System.out.println("User is not on Ethical investing page");
	      }
		
		Assert.assertTrue(helpLearningPage.isEthicalInvestingTextPresent("Ethical investing"));
	}


}
