package stepDefinitions;

import java.io.FileNotFoundException;

import org.junit.Assert;

import Cucumber.TestContext;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObjects.InvestmentsPage;
import pageObjects.PensionsPage;

public class InvestmentsPageSteps {
	
	TestContext testContext;
    InvestmentsPage investmentsPage;

    public InvestmentsPageSteps(TestContext context) throws FileNotFoundException {
        testContext = context;
        
        investmentsPage = testContext.getPageObjectManager().getInvestmentsPage();
    }
    
	@Given("^the user clicks on Investments Menu$")
	public void the_user_clicks_on_Investments_Menu() throws Throwable {

		investmentsPage.clickOn_InvestmentsMenu();
		
	}

	@When("^the user clicks on Top UK Shares link$")
	public void the_user_clicks_on_Top_UK_Shares_link() throws Throwable {
		
		investmentsPage.clickOn_LinkTopUKShares();

	}

	@Then("^the user is directed to the Top Performing UK Shares page$")
	public void the_user_is_directed_to_the_Top_Performing_UK_Shares_page() throws Throwable {
	
		investmentsPage.ObtainText_TopPerformingSharesText();
		
		if(investmentsPage.isTopSharesTextPresent("Top performing UK shares: risers and fallers")) {
	          System.out.println("User on Top performing UK shares page");
	      } else {
	          System.out.println("User is not on Top performing UK shares page");
	      }
		
		Assert.assertTrue(investmentsPage.isTopSharesTextPresent("Top performing UK shares: risers and fallers"));
	}

}
